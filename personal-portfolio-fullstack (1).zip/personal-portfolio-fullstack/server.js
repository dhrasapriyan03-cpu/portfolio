const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const projectSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  technologies: [String],
  category: String,
  github: String,
  featured: { type: Boolean, default: false }
}, { timestamps: true });

const messageSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, trim: true },
  message: { type: String, required: true, trim: true }
}, { timestamps: true });

const Project = mongoose.model("Project", projectSchema);
const Message = mongoose.model("Message", messageSchema);

app.get("/api/projects", async (req, res) => {
  try {
    const projects = await Project.find().sort({ featured: -1, createdAt: -1 });
    res.json(projects);
  } catch (error) {
    res.status(500).json({ message: "Unable to load projects." });
  }
});

app.post("/api/messages", async (req, res) => {
  try {
    const { name, email, message } = req.body;
    if (!name || !email || !message) {
      return res.status(400).json({ message: "Please complete all fields." });
    }
    const savedMessage = await Message.create({ name, email, message });
    res.status(201).json({ message: "Thanks! Your message has been received.", id: savedMessage._id });
  } catch (error) {
    res.status(500).json({ message: "Unable to send your message right now." });
  }
});

// Seed starter projects once: visit /api/seed after connecting MongoDB.
app.get("/api/seed", async (req, res) => {
  try {
    const count = await Project.countDocuments();
    if (count > 0) return res.json({ message: "Projects already exist." });

    await Project.insertMany([
      {
        title: "AI-Edge Healthcare Monitoring System",
        description: "A concept for wearable-based health monitoring that combines edge computing and AI to support continuous monitoring.",
        technologies: ["Python", "AI/ML", "IoT", "Edge Computing"],
        category: "AI / Healthcare",
        github: "https://github.com/dhrasapriyan03-cpu/smart-healthcare-ai-edge",
        featured: true
      },
      {
        title: "Smart Home Fault Diagnosis Assistant",
        description: "An intelligent decision-support project that uses AO* search concepts to help diagnose possible smart-home faults.",
        technologies: ["Artificial Intelligence", "AO* Search", "Python"],
        category: "Artificial Intelligence",
        github: "",
        featured: true
      },
      {
        title: "Arduino Radar System",
        description: "An Arduino-based radar project concept for detecting nearby objects and presenting distance information.",
        technologies: ["Arduino", "Sensors", "Embedded Systems"],
        category: "IoT / Embedded",
        github: "",
        featured: true
      }
    ]);
    res.json({ message: "Starter projects added successfully." });
  } catch (error) {
    res.status(500).json({ message: "Could not seed projects." });
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

mongoose.connect(process.env.MONGODB_URI)
  .then(() => {
    console.log("MongoDB connected");
    app.listen(PORT, () => console.log(`Portfolio running at http://localhost:${PORT}`));
  })
  .catch(error => {
    console.error("MongoDB connection failed:", error.message);
    process.exit(1);
  });