const projectGrid = document.getElementById("projectGrid");
const contactForm = document.getElementById("contactForm");
const formStatus = document.getElementById("formStatus");

document.getElementById("menuToggle").addEventListener("click", () => {
  document.getElementById("navLinks").classList.toggle("open");
});

document.querySelectorAll("#navLinks a").forEach(link => {
  link.addEventListener("click", () => document.getElementById("navLinks").classList.remove("open"));
});

async function loadProjects() {
  try {
    const response = await fetch("/api/projects");
    if (!response.ok) throw new Error("Could not load projects");
    const projects = await response.json();

    if (!projects.length) {
      projectGrid.innerHTML = '<p class="loading">No projects yet. Add projects to your database to display them here.</p>';
      return;
    }

    projectGrid.innerHTML = projects.map((project, index) => `
      <article class="project-card">
        <span class="project-number">0${index + 1} / ${project.category || "PROJECT"}</span>
        <h3>${escapeHTML(project.title)}</h3>
        <p>${escapeHTML(project.description)}</p>
        <div class="tags">${(project.technologies || []).map(tag => `<span>${escapeHTML(tag)}</span>`).join("")}</div>
        ${project.github ? `<a class="project-link" href="${safeURL(project.github)}" target="_blank" rel="noreferrer">View on GitHub ↗</a>` : ""}
      </article>
    `).join("");
  } catch (error) {
    projectGrid.innerHTML = '<p class="loading">Could not connect to the project database. Start the server and check MongoDB.</p>';
  }
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  })[char]);
}

function safeURL(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" ? escapeHTML(url.href) : "#";
  } catch {
    return "#";
  }
}

contactForm.addEventListener("submit", async event => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(contactForm).entries());
  formStatus.textContent = "Sending…";

  try {
    const response = await fetch("/api/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.message || "Message could not be sent.");
    formStatus.textContent = result.message;
    contactForm.reset();
  } catch (error) {
    formStatus.textContent = error.message || "Something went wrong.";
  }
});

loadProjects();