# Priyadharsan — Full-Stack Portfolio

A responsive portfolio website built with HTML, CSS, JavaScript, Node.js, Express and MongoDB.

## Features

- Responsive personal portfolio layout
- About, skills, projects and contact sections
- Projects loaded dynamically from MongoDB through an Express REST API
- Contact form saves messages to MongoDB
- Starter project records can be inserted using a seed endpoint

## Requirements

- Node.js 18+
- MongoDB Community Server, or a MongoDB Atlas database

## Run locally

1. Extract the ZIP and open this folder in VS Code.
2. Install dependencies:

   ```bash
   npm install
   ```

3. Copy `.env.example` to `.env` and set your MongoDB connection string.

4. Start MongoDB locally, or create a MongoDB Atlas cluster and paste its connection string into `.env`.

5. Start the website:

   ```bash
   npm run dev
   ```

6. Open `http://localhost:5000`.
7. Add the starter project data by visiting `http://localhost:5000/api/seed` once. Then refresh the portfolio.

## API routes

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/projects` | Get portfolio projects |
| GET | `/api/seed` | Insert the three starter projects once |
| POST | `/api/messages` | Save a contact message |

## Customize before publishing

- Update the About section and skills in `public/index.html`.
- Replace the sample project descriptions with your final project details.
- Add your LinkedIn URL and public contact email.
- Add a resume PDF in `public/` and create a download link if needed.
- Change the page title and meta description.

## Deploy

### Backend + frontend
Deploy the Node.js app to Render or Railway. Add `MONGODB_URI` and `PORT` as environment variables. The frontend is served by Express, so one deployment hosts both.

### Database
Use MongoDB Atlas for a hosted database. Configure its Network Access and database user, then set the Atlas connection string as `MONGODB_URI`.

### Important production notes
- Remove or protect the `/api/seed` route after inserting initial data.
- Add rate limiting, spam protection and stronger validation before public launch.
- Never commit `.env` or database credentials.
- Use HTTPS and restrict database access.
